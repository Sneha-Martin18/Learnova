# Attendance Service Django Project
