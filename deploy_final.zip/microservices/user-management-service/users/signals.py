# Signals are already defined in models.py
# This file is imported by apps.py to ensure signals are loaded
pass
